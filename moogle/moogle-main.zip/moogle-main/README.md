moogle

URL Of Class Slides
https://docs.google.com/presentation/d/1OG6qUvdetDJW9ab8kTe_mRdjVeWYgxWigUWaawnEfCo/edit?usp=sharing
